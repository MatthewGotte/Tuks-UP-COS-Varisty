import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'extensionremover'
})
export class ExtensionremoverPipe implements PipeTransform {

  transform(fileName : string): string {
    var extStart = fileName.lastIndexOf('.');
    return fileName.substring(0, extStart);
  }

}
