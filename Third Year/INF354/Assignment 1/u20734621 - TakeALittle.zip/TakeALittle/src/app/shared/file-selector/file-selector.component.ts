import { Component, OnInit } from '@angular/core';
import { Photo } from '../photo-class/photo.component';

@Component({
  selector: 'app-file-selector',
  templateUrl: './file-selector.component.html',
  styleUrls: ['./file-selector.component.css']
})

export class FileSelectorComponent implements OnInit {

  heading = "Select files:";
  images = new Array();
  chosen = "";
  error = "";
  imgCount = 0;

  constructor() { }

  ngOnInit(): void {
  }

  selectFile(event: any) {
    const files = event.target.files;
    this.error = "";

    if (!this.checkFileType(files)) return;

    if (files.length > 2) {
      this.error = "Only 2 images may be uploaded";
      return;
    }

    if (files.length == 2) {
      this.heading = "Replace files:";
      this.chosen = "Chosen files:";
      this.imgCount = 0;
      this.images.splice(0);
      this.assignPhoto(files[0]);
      this.assignPhoto(files[1]);
      return;
    }

    if (this.imgCount == 0) {
      //img 1 has not been uploaded yet:
      this.heading = "Select last file:";
      this.chosen = "Chosen file:";
      this.assignPhoto(files[0]);
    }
    else if (this.imgCount == 1) {
      //img 1 has been uploaded but not image 2:
      this.heading = "Replace files:";
      this.chosen = "Chosen files:";
      this.assignPhoto(files[0]);
    } 
    else {
      this.heading = "Select last file:";
      this.chosen = "Chosen file:";
      this.images.shift();
      this.imgCount--;
      this.assignPhoto(files[0]);
    }
  }

  checkFileType(f : any) : boolean {
    for (let i = 0; i < f.length; i++) {
      let mime = f[i].type;
      if (mime.match(/image\/*/) == null) {
        this.error = "Please upload images only";
        return false;
      }
    }
    return true;
  }

  assignPhoto(files : any) {
    var reader = new FileReader();
    reader.readAsDataURL(files);
    reader.onload = (img : any) => {
      var newPhoto = new Photo(files.name, new Date().toUTCString(), img.target.result);
      this.images.unshift(newPhoto);
    }
    this.imgCount++;
  }

}
