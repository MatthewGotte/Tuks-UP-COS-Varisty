export class Photo {

    isSet: boolean;
    name : string;
    upload_date : string;
    URL : string;

    constructor(name : string, upload_date : string, URL : string) {
        this.isSet = true;
        this.name = name;
        this.upload_date = upload_date;
        this.URL = URL;
    }

    isUploaded() : boolean {
        return this.isSet;
    }

    overwrite(name : string, upload_date : string, URL : string) {
        this.name = name;
        this.upload_date = upload_date;
        this.URL = URL;
    }

    getName() : string {
        return this.name;
    }

    getUploadDate() : string {
        return this.upload_date;
    }

    getURL() : string {
        return this.URL;
    }

    delete() {
        this.isSet = false;
        this.name = "";
        this.upload_date = "";
        this.URL = "";
    }
}