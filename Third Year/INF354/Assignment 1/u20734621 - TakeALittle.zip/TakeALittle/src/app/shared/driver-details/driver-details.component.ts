import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-driver-details',
  templateUrl: './driver-details.component.html',
  styleUrls: ['./driver-details.component.css']
})
export class DriverDetailsComponent implements OnInit {

  detailsForm! : FormGroup;
  frmBuilder! : FormBuilder;
  submit = false;

  constructor(f: FormBuilder, private router : Router) { this.frmBuilder = f }

  ngOnInit(): void {
    this.detailsForm = this.frmBuilder.group({
      FullName: ['', this.validateFullName],
      IDNumber: ['', this.validateIDNumber],
      OTP: ['', this.validateOTP]
    });
  }

  onNextClick() {
    this.submit = true;

    for (var input in this.detailsForm.controls) {
      if (this.detailsForm.controls[input].invalid) {
        return;
      }
    }

    //form is valid here, can be redirected to the next page:
    this.router.navigate(['/identificationcardimage'])
  }

  //validation of Full Name:
  validateFullName(FullName : FormControl) : {[valtype : string] : string} | null {
    let FullNameString = FullName.value;
    if (FullNameString.length < 1) {
      return {'errormsg' : 'Please enter name'}
    }
    return null;
  }

  validateIDNumber(id : FormControl) : {[valtype : string] : string} | null {
    let IDNum = id.value;
    //check length:
    if (IDNum.length != 13) {
      return {'errormsg' : 'Please enter id number'}
    }
    //validate with check digit:
    var checkdigit = 0;
    var count = 0;
    for (var i = 0; i < IDNum.length - 1; i++) {
      var multiple = count % 2 + 1;
      count++;
      var temp = multiple * + IDNum[i];
      temp = Math.floor(temp / 10) + (temp % 10);
      checkdigit += temp;
    }
    checkdigit = (checkdigit * 9) % 10;
    if (checkdigit != IDNum[IDNum.length - 1]) {
      return {'errormsg': 'Entered id number is not valid'}
    }
    return null;
  }

  // //validation of OTP:
  validateOTP(OTP : FormControl) : {[valtype : string] : string} | null {
    let OTPNum = OTP.value;
    if (OTPNum.length < 1) {
      return {'errormsg' : 'Please enter OTP'}
    }
    return null;
  }

}
