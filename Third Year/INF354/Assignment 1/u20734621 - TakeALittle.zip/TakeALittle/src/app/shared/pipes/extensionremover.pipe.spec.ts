import { ExtensionremoverPipe } from './extensionremover.pipe';

describe('ExtensionremoverPipe', () => {
  it('create an instance', () => {
    const pipe = new ExtensionremoverPipe();
    expect(pipe).toBeTruthy();
  });
});
