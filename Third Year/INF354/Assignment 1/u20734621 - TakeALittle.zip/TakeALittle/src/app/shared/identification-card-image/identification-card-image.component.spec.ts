import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IdentificationCardImageComponent } from './identification-card-image.component';

describe('IdentificationCardImageComponent', () => {
  let component: IdentificationCardImageComponent;
  let fixture: ComponentFixture<IdentificationCardImageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IdentificationCardImageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IdentificationCardImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
