import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-identification-card-image',
  templateUrl: './identification-card-image.component.html',
  styleUrls: ['./identification-card-image.component.css']
})
export class IdentificationCardImageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
