import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DriverDetailsComponent } from './shared/driver-details/driver-details.component';
import { IdentificationCardImageComponent } from './shared/identification-card-image/identification-card-image.component';

const routes: Routes = [
  {path: 'driverdetails', component: DriverDetailsComponent},
  {path: '', redirectTo: 'driverdetails', pathMatch: 'full'},
  {path: 'identificationcardimage', component: IdentificationCardImageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
