import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { DriverDetailsComponent } from './shared/driver-details/driver-details.component';
import { IdentificationCardImageComponent } from './shared/identification-card-image/identification-card-image.component';
import { FileSelectorComponent } from './shared/file-selector/file-selector.component';
import { ExtensionremoverPipe } from './shared/pipes/extensionremover.pipe';


@NgModule({
  declarations: [
    AppComponent,
    DriverDetailsComponent,
    IdentificationCardImageComponent,
    FileSelectorComponent,
    ExtensionremoverPipe,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
