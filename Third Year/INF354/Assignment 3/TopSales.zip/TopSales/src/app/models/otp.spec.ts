import { OTP } from './otp';

describe('OTP', () => {
  it('should create an instance', () => {
    expect(new OTP()).toBeTruthy();
  });
});
