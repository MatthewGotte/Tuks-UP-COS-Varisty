﻿namespace Assignment3_API.ViewModels
{
    public class OTP
    {
        public UserViewModel uvm { get; set; }
        public string value { get; set; }
    }
}
