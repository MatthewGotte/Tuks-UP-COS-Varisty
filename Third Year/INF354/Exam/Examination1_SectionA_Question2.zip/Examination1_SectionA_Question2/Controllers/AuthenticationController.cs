﻿using Examination1_SectionA_Question2.Models;
using Examination1_SectionA_Question2.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Examination1_SectionA_Question2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly UserManager<AppUser> _userManager;

        public AuthenticationController(UserManager<AppUser> userManager)
        {
            _userManager = userManager; 
        }

        ///////////////////////////////////////////////////
        // Create the RegisterUser endpoint/method below //
        ///////////////////////////////////////////////////
    }
}
