export enum PomodoroStatus {
    Working = 0,
    OnBreak = 1
}