import { Component } from '@angular/core';
import { Timer } from "easytimer.js";
import { PomodoroStatus } from './models/PomodoroStatus.enum';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {

  currentTimeSlot : string = "00:00:00";
  currentStatus : PomodoroStatus = PomodoroStatus.OnBreak;
  timer : Timer = new Timer();

  constructor() {
    this.resetPomodoroSessions();
  }

  isWorking () : boolean {
    
    return true;//TODO: change this line to check if current status is equal to working
  }

  StartWorkSession() {
    this.timer.stop();
    this.timer.start({countdown: true, startValues: {minutes: 25}});
    
    //TODO: set current status to working
  }

  StartBreak() {
    this.timer.stop();
    this.timer.start({countdown: true, startValues: {minutes: 10}});

    //TODO: set current status to on break
  }

  resetPomodoroSessions() {
    this.timer = new Timer();
    this.timer.addEventListener('secondsUpdated',  (e) => {
      this.currentTimeSlot = this.timer.getTimeValues().toString();
    })
    this.timer.addEventListener('targetAchieved', e=> { this.playNotification();})
    
    
    //TODO: set current status to on break
  }

  playNotification() {
    var snd = new Audio("assets/beep.wav");  
    snd.play();
  }
}
