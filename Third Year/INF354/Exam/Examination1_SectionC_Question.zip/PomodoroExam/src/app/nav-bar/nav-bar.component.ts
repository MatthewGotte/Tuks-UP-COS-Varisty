import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html'
})
export class NavBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  onResetButtonClicked() {
    //TODO: notify app component to call its resetPomodoroSessions() method.
  }

}
