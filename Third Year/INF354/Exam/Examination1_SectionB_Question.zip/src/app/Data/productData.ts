export const productData = [
  {
    "name": "Hamburgers",
    "value": 1910
  }, {
    "name": "Fried Chips",
    "value": 1466
  }, {
    "name": "Toasties",
    "value": 702
  }, {
    "name": "Fizzy Drinks",
    "value": 1558
  }, {
    "name": "Hot Drinks",
    "value": 1446
  }, {
    "name": "Desserts",
    "value": 788
  }
];
