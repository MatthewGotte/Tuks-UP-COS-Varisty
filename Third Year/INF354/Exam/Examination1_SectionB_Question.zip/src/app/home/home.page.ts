import { Component } from '@angular/core';
import { ActionSheetController } from '@ionic/angular';
import { ChartDataset } from 'chart.js';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { productData } from '../Data/productData';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  tableData: any;
  barChartData: ChartDataset[] = [];
  barChartLabels: Array<any> = [];
  barChartOptions: any = {
    responsive: true,
  };
  barChartLegend: boolean = true;
  barChartType: string = 'bar';
  showData: boolean = false;
  products: any[] = [];
  values: number[] = [];

// -- ------------------------------------------------
// DO NOT EDIT ABOVE THIS LINE
// --------------------------------------------------
  constructor() {}

  async presentActionSheet() {
// -- ------------------------------------------------
// COMPLETE Q1.1 BELOW THIS LINE
// --------------------------------------------------

  }

  generateReport() {
    this.showData = true;

// -- ------------------------------------------------
// COMPLETE Q1.2 BELOW THIS LINE
// --------------------------------------------------

  }

  openPDF(){
    let Data = document.getElementById('htmlData')!;
    // Canvas Options
    html2canvas(Data).then((canvas) => {

      let fileWidth = 210;
      let fileHeight = (canvas.height * fileWidth) / canvas.width;

      const contentDataURL = canvas.toDataURL('image/png');

// -- ------------------------------------------------
// COMPLETE Q1.3 BELOW THIS LINE
// --------------------------------------------------


    });
  }


// -- ------------------------------------------------
// DO NOT EDIT BELOW THIS LINE
// --------------------------------------------------
  generateTable() {
    this.tableData = productData;
  }
}
