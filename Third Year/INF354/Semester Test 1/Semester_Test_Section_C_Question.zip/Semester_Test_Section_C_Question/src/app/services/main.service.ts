import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class MainService {

constructor() { }

/**
*
* SECTION C - Question 1 (Complete the service)
*/


}
