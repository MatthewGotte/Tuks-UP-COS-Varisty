import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'semtest-chatstats',
  templateUrl: './chatstats.component.html',
  styleUrls: ['./chatstats.component.css']
})
export class ChatstatsComponent implements OnInit {

  //TODO: create your stats variables here

  constructor() {
  }

  ngOnInit(): void {
  }

  //TODO: create your method for receiving each message here

}
