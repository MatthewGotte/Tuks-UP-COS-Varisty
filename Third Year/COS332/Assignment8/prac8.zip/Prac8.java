// u20734621 - Matthew Gotte, u20662302 - Ryan Healy
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.Scanner;

class Prac8
{
    public static void main(String[] args) 
    {
        try
        {
            while (true) 
            {
                Path indexDir = FileSystems.getDefault().getPath(System.getProperty("user.dir"));
                WatchService watcher = FileSystems.getDefault().newWatchService();
                WatchKey k = indexDir.register(watcher, StandardWatchEventKinds.ENTRY_MODIFY);
                WatchKey wk = watcher.take();
                
                for (WatchEvent<?> event : wk.pollEvents()) 
                {
                    Path changed = (Path) event.context();

                    if (changed.endsWith("index.html")) 
                    {
                        sendChangedFile();
                    }
                }

                boolean valid = wk.reset();

                if (!valid) 
                {
                    System.out.println("The file can no longer be watched");
                    System.exit(0);
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void sendChangedFile()
    {
        try
        {
            // connect to server
            Socket sock = new Socket("192.168.88.249", 21);
            BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));

            String response = getResponse(in);

            if (!response.startsWith("220 ")) 
            {
                sock.close();
                System.out.println("Unknown response received when connecting to the FTP server: " + response);
                System.exit(0);
            }

            // login to server
            sendCommand("USER ryserver", sock, out);

            response = getResponse(in);
            if (!response.startsWith("331 ")) 
            {
                sock.close();
                System.out.println("Unknown response received after sending the user: " + response);
                System.exit(0);
            }

            sendCommand("PASS hello", sock, out);

            response = getResponse(in);
            if (!response.startsWith("230 ")) 
            {
                sock.close();
                System.out.println("Unable to log in to the FTP server: " + response);
                System.exit(0);
            }

            // send file
            BufferedInputStream fileStream = new BufferedInputStream(new FileInputStream(new File("index.html")));

            sendCommand("PASV", sock, out);
            response = getResponse(in);

            if (!response.startsWith("227 ")) 
            {
                sock.close();
                System.out.println("Unable to change to passive mode: " + response);
                System.exit(0);
            }

            String dataAddress = null;
            int dataPort = -1;
            int opening = response.indexOf('(');
            int closing = response.indexOf(')', opening + 1);
            
            if (closing > 0) 
            {
                String dataLink = response.substring(opening + 1, closing);
                Scanner sc = new Scanner(dataLink).useDelimiter(",");

                try 
                {
                    dataAddress = sc.next() + "." + sc.next() + "." + sc.next() + "." + sc.next();
                    dataPort = Integer.parseInt(sc.next()) * 256 + Integer.parseInt(sc.next());
                } 
                catch (Exception e) 
                {
                    sock.close();
                    System.out.println("Unable to parse data link: " + response);
                    System.exit(0);
                }

                sc.close();
            }

            sendCommand("STOR index.html", sock, out);

            Socket dataSock = new Socket(dataAddress, dataPort);

            response = getResponse(in);

            if (!response.startsWith("150 ")) 
            {
                sock.close();
                dataSock.close();
                System.out.println("Denied permission to send to send updated file: " + response);
                System.exit(0);
            }

            BufferedOutputStream dataOut = new BufferedOutputStream(dataSock.getOutputStream());
            
            byte[] fileBytes = new byte[(int)new File("index.html").length()];
            fileStream.read(fileBytes);

            dataOut.write(fileBytes);
            dataOut.flush();

            dataOut.close();
            fileStream.close();

            response = getResponse(in);

            if (response.startsWith("226 "))
            {
                System.out.println("Successfuly transfered file");
            }
            else
            {
                System.out.println("Failed to transfer file");
            }

            sock.close();
            dataSock.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void sendCommand(String command, Socket sock, BufferedWriter out) throws IOException 
    {
        out.write(command + "\r\n");
        out.flush();

        System.out.println(" Command: " + command);
    }

    public static String getResponse(BufferedReader in) throws IOException 
    {
        String res = in.readLine();

        System.out.println("Response: " + res);
        System.out.println();

        return res;
    }
}