#include <iostream>
#include <sstream>
#include <cmath>
#include <fstream>

using namespace std;

int highest(int arr[], int size);
string print(int arr[], int size);

int main()
{
	int spaces = 0, pos, high;
	string sline;
	ifstream tfile;
	int * arr;
	
	tfile.open("values.txt");
	if (tfile)
	{
		while (getline(tfile, sline))
		{
			pos = sline.find(';');
			istringstream ss(sline.substr(0, pos));
			ss >> spaces;
			sline.erase(0, pos + 1);
			arr = new int[spaces];
			
			//Write to array:
			for (int i = 0; i < spaces; i++)
			{
				pos = -1;
				pos = sline.find(',');
				if (pos != -1)
				{
					istringstream ss(sline.substr(0, pos));
					ss >> arr[i];
					sline.erase(0, pos + 1);
				}
				else
				{
					istringstream ss(sline);
					ss >> arr[i];
					break;
				}
			}
			
			high = highest(arr, spaces);
			
			//Re-write array from mod value:
			for (int i = 0; i < spaces; i++)
			{
				if (high % 2 == 0)
				{
					arr[i] = arr[i] * high;
				}
				else
				{
					arr[i] = pow(arr[i], 2);
				}
			}
			
			cout << print(arr, spaces) << endl;
			
			delete [] arr;
		}
	}
	
	
	return 0;
}

string print(int arr[], int size)
{
	string output = "";
	
	for (int i = 0; i < size; i++)
	{
		if (i != size - 1)
			output += to_string(arr[i]) + ",";
		else 
			output += to_string(arr[i]);
	}
	
	return output;
}

int highest(int arr[], int size)
{
	int highest;
	
	highest = arr[0];
	for (int i = 0; i < size; i++)
	{
		if (arr[i] > highest)
			highest = arr[i];
	}
	
	return highest;
}