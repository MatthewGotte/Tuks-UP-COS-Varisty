#include <iostream>
#include <sstream>
#include <fstream>
#include <cmath>

using namespace std;

int main()
{
	ifstream tfile;
	int rows, cols, odd = 0, even = 0, largest, smallest, pos;
	int ** arr;
	string sline;
	
	tfile.open("matrix.txt");
	
	if (tfile)
	{
		
		tfile >> sline;
		
		//Get Rows:
		pos = sline.find(',');
		istringstream ss(sline.substr(0, pos));
		ss >> rows;
		
		//Get Columns:
		sline.erase(0, pos + 1);
		istringstream zz(sline);
		zz >> cols;
		
		//Declare Array:
		arr = new int * [rows];
		for (int i = 0; i < rows; i++)
			arr[i] = new int[cols];
		
		//Write Values to matrix:
		for (int i = 0; i < rows; i++)
		{
			tfile >> sline;
			for (int z = 0; z < cols; z++)
			{
				//Copy and convert values:
				pos = -1;
				pos = sline.find(',');
				if (pos != -1)
				{
					istringstream ss(sline.substr(0, pos));
					ss >> arr[i][z];
					sline.erase(0,  pos + 1);
				}
				else
				{
					istringstream ss(sline);
					ss >> arr[i][z];
					break;
				}
			}
		}
		
		//Evens:
		for (int i = 0; i < rows; i++)
		{
			for (int z = 0; z < cols; z++)
			{
				if (arr[i][z] % 2 == 0)
					even++;
			}
		}
		//Odds:
		for (int i = 0; i < rows; i++)
		{
			for (int z = 0; z < cols; z++)
			{
				if (arr[i][z] % 2 != 0)
					odd++;
			}
		}
		//Largest:
		largest = arr[0][0];
		for (int i = 0; i < rows; i++)
		{
			for (int z = 0; z < cols; z++)
			{
				if (arr[i][z] > largest)
					largest = arr[i][z];
			}
		}
		//Smallest:
		smallest = arr[0][0];
		for (int i = 0; i < rows; i++)
		{
			for (int z = 0; z < cols; z++)
			{
				if (arr[i][z] < smallest)
					smallest = arr[i][z];
			}
		}
	
		//Outputs:
		cout << "Count Odd: " << to_string(odd) << endl;
		cout << "Count Even: " << to_string(even) << endl;
		cout << "Largest Number: " << to_string(largest) << endl;
		cout << "Smallest Number: " << to_string(smallest) << endl;
	}
	
	delete [] arr;
	tfile.close();
	return 0;
}
