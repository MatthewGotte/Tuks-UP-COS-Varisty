#include <iostream>
#include <string>
#include "piece.h"
#include "board.h"
#include "solver.h"

using namespace std;

int main()
{
	return 0;
}