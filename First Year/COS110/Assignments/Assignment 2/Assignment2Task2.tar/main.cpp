#include "matrix.h"
#include <fstream>
#include <string>
#include <stdlib.h>

using namespace std;

int main() {
    /* infile("input.txt");
    ifstream infile2("inputb.txt");
    Matrix a(2, 2);
    Matrix b(2, 1);
    cout << a << endl;
    cout << b << endl;

    infile >> a;
    infile2 >> b;
    cout << a << endl;
    cout << b << endl;
    infile.close();
    infile2.close();*/

     /*Matrix x(2,2);
    ifstream tfile;
    tfile.open("input.txt");
    tfile >> x;
    tfile.close();
    tfile.clear();
    tfile.open("inputb.txt");
    Matrix y(2,2);
    tfile >> y;


    cout << y << endl << (y^4) << endl;
    y ^= 4;
    cout << y << endl;*/

    return 0;
}
/* Output
0         0
0         0

0
0

12        3
2        -3

15
13
 */