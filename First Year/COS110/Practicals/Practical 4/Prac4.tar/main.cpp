#include <iostream>
#include <string>

#include "tome.h"

using namespace std;

int main()
{
    /*string * x = new string[3];
    x[0] = "Big Spell";
    x[1] = "Spell 2";
    x[2] = "Damn big spells";

    string * y = new string[4];
    y[0] = "Big Spell";
    y[1] = "Spell 2";
    y[2] = "Damn big spells";
    y[3] = "One More Spell here";

    tome t1("Tome 1", 3, "Matthew", x);
    tome t2("Tome 2", 4, "Matthew Gotte", y);

    t2 = t2 - "One More Spell here";


    cout << endl << t1 << endl << t2 << endl;

    if (t1 == t2)
        cout << endl << "EQUAL" << endl;
    else
        cout << endl << "UNEQUAL" << endl;

    if (t1 > t2)
        cout << endl << "t1 Greater" << endl;
    else
        cout << endl << "t1 not greater" << endl;

    if (t1 < t2)
        cout << endl << "t2 greater" << endl;
    else
        cout << endl << "t2 not greater" << endl;*/


    return 0;
}