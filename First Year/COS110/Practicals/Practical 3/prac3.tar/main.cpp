#include "cauldron.h"
#include "ingredient.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

int main()
{
	/*//First constructor
	cout << "CAULDRON 1" << endl;
	cauldron myCauldron("list.txt",20);
	myCauldron.listIngredients();
	cout << endl;
	myCauldron.print();
	cout << endl;
	
	cout << "CAULDRON 2" << endl;
	cauldron cauldron2("list.txt",5); 
	cauldron2.listIngredients();
	cout << endl;
	cauldron2.print();
	cout << endl;
	
	//Operator
	cout << "CAULDRON 3" << endl;
	cauldron cauldron3("list.txt",5);
	cauldron3 = myCauldron;
	cauldron3.listIngredients();
	cout << endl;
	cauldron3.print();
	cout << endl;
	
	//Second constructor
	cout << "CAULDRON 4" << endl;
	cauldron cauldron4(&cauldron2);
	cauldron4.listIngredients();
	cout << endl;
	cauldron4.print();
	cout << endl;
	
	//Add to first
	cout << "CAULDRON 1" << endl;
	myCauldron.addIngredient("tongue",75);
	myCauldron.listIngredients();
	cout << endl;
	myCauldron.print();
	cout << endl;
	myCauldron.addIngredient("tongue2",75);
	myCauldron.listIngredients();
	cout << endl;
	myCauldron.print();
	cout << endl;
	
	
	//Add to second
	cout << "CAULDRON 4" << endl;
	cauldron4.addIngredient("leaf",56);
	cauldron4.listIngredients();
	cout << endl;
	cauldron4.print();
	cout << endl;
	
	//Add to operator
	cout << "CAULDRON 3" << endl;
	cauldron3.addIngredient("pear",10);
	cauldron3.listIngredients();
	cout << endl;
	cauldron3.print();
	cout << endl;

	//Remove from first
	cout << "CAULDRON 1" << endl;
	myCauldron.removeIngredient(4);
	myCauldron.removeIngredient(10);
	myCauldron.removeIngredient(11);
	myCauldron.addIngredient("apple",10);
	myCauldron.listIngredients();
	cout << endl;
	myCauldron.print();
	cout << endl;
	
	string array[4] = {"ear","hair","teeth","salt"};
	//Distill
	myCauldron.distillPotion(myCauldron, array, 4);
	cout << "CAULDRON 1" << endl;
	myCauldron.listIngredients();
	cout << endl;
	myCauldron.print();
	cout << endl;*/
	
	return 0;
}