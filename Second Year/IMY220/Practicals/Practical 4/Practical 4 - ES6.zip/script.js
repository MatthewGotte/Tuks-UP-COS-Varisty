function MultipleChecker()
{
	this.isMultiple = function(num, multiplication)
	{
		return num % multiplication === 0;

	}//end function

	this.fillArray = function(length, multiplication)
	{
		var arr = [];

		for(let i = 0; i < length; i++)
		{
			arr.push((i + 1) * multiplication);

		}//end for

		return arr;

	}//end function

}//end MultipleChecker


function checkPangram(sentence)
{
	var alphabet = "abcdefghijklmnopqrstuvwxyz";

	// convert to character array
	alphabet = alphabet.split("");

	// convert to lowercase
	sentence = sentence.toLowerCase();

	return alphabet.every(function(element, index)
	{
		return sentence.indexOf(element) > -1;

	});

}//end checkPangram


const vowels = ["a", "e", "i", "o", "u"];


const checker = new MultipleChecker();

document.getElementById("checkMultipleBtn").onclick = function()
{
	document.getElementById("multipleResult").innerHTML = checker.isMultiple(document.getElementById("multipleChecker").value, document.getElementById("multiplicationTable1").value);
}

document.getElementById("getmultipleList").onclick = function()
{
	document.getElementById("multipleListResult").innerHTML = checker.fillArray(document.getElementById("multipleList").value, document.getElementById("multiplicationTable2").value);
}

document.getElementById("checkPangram").onclick = function()
{
	document.getElementById("pangramResult").innerHTML = checkPangram(document.getElementById("pangramChecker").value);
}