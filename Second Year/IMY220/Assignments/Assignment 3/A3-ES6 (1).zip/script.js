const quizzes = [
	{quiz: "The Cats Quiz", creator: "I_Make_Quizzes", score: 74},
	{quiz: "Do You Know Marvel?", creator: "QuizLover55", score: 48},
	{quiz: "Do You Know Disney?", creator: "QuizLover55", score: 78},
	{quiz: "The Dogs Quiz", creator: "I_Make_Quizzes", score: 45},
	{quiz: "Random Trivia Quiz", creator: "ThatTrviaMastr", score: 88},
	{quiz: "Anime Trivia Quiz", creator: "ThatTrviaMastr", score: 68},
	{quiz: "The Movies Quiz", creator: "I_Make_Quizzes", score: 80},
	{quiz: "Do You Know Your Memes?", creator: "QuizLover55", score: 75},
	{quiz: "Game Trivia Quiz", creator: "ThatTrviaMastr", score: 62},
];