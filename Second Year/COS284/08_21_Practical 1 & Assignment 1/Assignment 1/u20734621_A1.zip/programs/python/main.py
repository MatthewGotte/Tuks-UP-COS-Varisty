#!/usr/bin/env python
print "The quick brown fox jumps over the lazy dog."