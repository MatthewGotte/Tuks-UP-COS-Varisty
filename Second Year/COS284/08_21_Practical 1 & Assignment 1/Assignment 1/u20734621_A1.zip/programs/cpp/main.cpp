#include "iostream"

using namespace std;

int main() {
	cout << "The quick brown fox jumps over the lazy dog." << endl;
	return 0;
}
