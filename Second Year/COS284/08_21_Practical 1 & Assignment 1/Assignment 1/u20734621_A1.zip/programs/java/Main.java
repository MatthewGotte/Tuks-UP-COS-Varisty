class Main {
  public static void main(String [] args) {
    System.out.println("The quick brown fox jumps over the lazy dog.");
  }
}
