for i in {1..100}
do
    java Main
    echo ""
done