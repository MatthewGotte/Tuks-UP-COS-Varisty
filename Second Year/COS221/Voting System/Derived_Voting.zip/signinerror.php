<?php   
    echo '<h1 id="reqsignin">Please sign in before trying to access the functionality</h1>';