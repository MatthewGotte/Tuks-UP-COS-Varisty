    <div>
        <h1>Why you should vote</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dicta facere non vero quo, a sapiente, eos voluptas, vel iste at explicabo sunt suscipit ea esse aliquam tempora ratione consequatur.</p>
    </div>
    <div>
        <h1>How to register</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem sapiente consequuntur aut accusantium velit aspernatur nostrum iste tempora molestiae omnis cum id a, labore eligendi reiciendis nihil. Ducimus, impedit repudiandae.</p>
    </div>