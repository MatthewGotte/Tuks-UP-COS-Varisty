<?php
    echo '<div class="headerblock">';
    echo '<img src="./img/flag-south-africa.svg" id="logo" />';
    echo '<div class=" titleblock ">';
    echo '<h1 id="mainhead">DERIVED VOTING</h1>';
    echo '</div>';
    echo '</div>';
?>