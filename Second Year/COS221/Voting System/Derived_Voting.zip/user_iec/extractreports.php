<?
    echo exec('output.xml');
?>