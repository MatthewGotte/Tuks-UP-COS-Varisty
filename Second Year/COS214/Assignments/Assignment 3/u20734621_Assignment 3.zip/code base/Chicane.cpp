#include "Chicane.h"

Chicane::Chicane() : Section() {

}

Chicane::~Chicane() {

}

void Chicane::print() {
    cout << "Chicane";
}