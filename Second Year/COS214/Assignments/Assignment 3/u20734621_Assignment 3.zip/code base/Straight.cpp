#include "Straight.h"

Straight::Straight() : Section() {

}

Straight:: ~Straight() {

}

void Straight::print() {
    cout << "Straight";
}