#include "SoldierFactory.h"

SoldierFactory::SoldierFactory() {

}

SoldierFactory::~SoldierFactory() {

}