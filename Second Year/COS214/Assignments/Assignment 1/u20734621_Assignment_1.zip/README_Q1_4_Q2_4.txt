Question 1.4: Template Method

Quesiton 2.4: Factory Method
