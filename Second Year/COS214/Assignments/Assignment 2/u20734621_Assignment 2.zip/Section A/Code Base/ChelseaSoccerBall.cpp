#include "ChelseaSoccerBall.h"

ChelseaSoccerBall::ChelseaSoccerBall(bool inflated) : SoccerBall("Chelsea", 120.42, inflated){

}