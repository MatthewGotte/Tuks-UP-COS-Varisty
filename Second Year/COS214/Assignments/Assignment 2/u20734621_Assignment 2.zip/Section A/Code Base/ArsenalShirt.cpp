#include "ArsenalShirt.h"

ArsenalShirt::ArsenalShirt(string size) : Shirt("Arsenal", 80.32, size) {

}

