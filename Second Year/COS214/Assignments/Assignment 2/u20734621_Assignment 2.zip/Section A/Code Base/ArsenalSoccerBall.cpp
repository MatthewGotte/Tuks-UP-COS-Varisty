#include "ArsenalSoccerBall.h"

ArsenalSoccerBall::ArsenalSoccerBall(bool inflated) : SoccerBall("Arsenal", 140.52, inflated) {

}