#ifndef CHELSEASHIRT_H
#define CHELSEASHIRT_H

#include "Shirt.h"

class ChelseaShirt : public Shirt {
private:

public:
    ChelseaShirt(string size);
};

#endif