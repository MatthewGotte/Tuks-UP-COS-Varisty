#include "ChelseaShirt.h"

ChelseaShirt::ChelseaShirt(string size) : Shirt("Chelsea", 90.57, size) {

}