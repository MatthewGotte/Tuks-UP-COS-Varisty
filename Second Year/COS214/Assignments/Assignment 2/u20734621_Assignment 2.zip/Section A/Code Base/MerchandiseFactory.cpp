#include "MerchandiseFactory.h"

MerchandiseFactory::MerchandiseFactory() {}

MerchandiseFactory::~MerchandiseFactory() {}