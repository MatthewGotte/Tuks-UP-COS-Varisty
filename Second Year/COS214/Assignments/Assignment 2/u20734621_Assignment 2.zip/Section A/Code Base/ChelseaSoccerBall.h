#ifndef CHELSEASOCCERBALL_H
#define CHELSEASOCCERBALL_H

#include "SoccerBall.h"

class ChelseaSoccerBall : public SoccerBall {
private:

public:
    ChelseaSoccerBall(bool inflated);
};

#endif