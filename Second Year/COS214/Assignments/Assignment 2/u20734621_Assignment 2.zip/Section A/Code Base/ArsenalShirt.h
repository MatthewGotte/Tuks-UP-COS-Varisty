#ifndef ARSENALSHIRT_H
#define ARSENALSHIRT_H

#include "Shirt.h"

class ArsenalShirt : public Shirt {
private:

public:
    ArsenalShirt(string size);
};

#endif