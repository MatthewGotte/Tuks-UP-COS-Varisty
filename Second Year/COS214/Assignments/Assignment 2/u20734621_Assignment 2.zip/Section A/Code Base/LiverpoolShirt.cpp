#include "LiverpoolShirt.h"

LiverpoolShirt::LiverpoolShirt(string size) : Shirt("Liverpool", 10.87, size) {

}