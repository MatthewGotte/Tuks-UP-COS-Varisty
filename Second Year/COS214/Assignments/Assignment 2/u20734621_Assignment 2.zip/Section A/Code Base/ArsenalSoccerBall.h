#ifndef ARSENALSOCCERBALL_H
#define ARSENALSOCCERBALL_H

#include "SoccerBall.h"

class ArsenalSoccerBall : public SoccerBall {
private:

public:
    ArsenalSoccerBall(bool inflated);
};

#endif