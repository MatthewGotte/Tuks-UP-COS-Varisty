#ifndef LIVERPOOLSOCCERBALL_H
#define LIVERPOOLSOCCERBALL_H

#include "SoccerBall.h"

class LiverpoolSoccerBall : public SoccerBall {
private:

public:
    LiverpoolSoccerBall(bool inflated);
};

#endif