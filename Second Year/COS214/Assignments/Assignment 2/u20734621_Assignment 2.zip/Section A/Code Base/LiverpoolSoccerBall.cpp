#include "LiverpoolSoccerBall.h"

LiverpoolSoccerBall::LiverpoolSoccerBall(bool inflated) : SoccerBall("Liverpool", 110.32, inflated) {

}