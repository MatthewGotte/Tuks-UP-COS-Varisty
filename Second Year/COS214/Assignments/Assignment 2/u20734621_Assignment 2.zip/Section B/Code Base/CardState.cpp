#include "CardState.h"

string CardState::getCardColour() {
    return cardColour;
}
