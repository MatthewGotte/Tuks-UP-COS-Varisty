#include "AttackPlayStyle.h"


string AttackPlayStyle::play() {
    return "is attacking the opposition's goal with the ball.";
}