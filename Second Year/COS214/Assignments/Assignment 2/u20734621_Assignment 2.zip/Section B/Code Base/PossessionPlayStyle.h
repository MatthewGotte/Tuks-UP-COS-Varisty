#ifndef POSSESSIONPLAYSTYLE_H
#define POSSESSIONPLAYSTYLE_H

#include "PlayStyle.h"

class PossessionPlayStyle : public PlayStyle {
public:
    string play();
};


#endif
