#include "DefendPlayStyle.h"

string DefendPlayStyle::play() {
    return "is defending the team's half of the field.";
}