#ifndef DEFENDPLAYSTYLE_H
#define DEFENDPLAYSTYLE_H

#include "PlayStyle.h"

class DefendPlayStyle : public PlayStyle {
public:
    string play();
};


#endif
