#include "PossessionPlayStyle.h"

string PossessionPlayStyle::play() {
    return "is helping the team keep possession of the ball by passing it to their teammates.";
}