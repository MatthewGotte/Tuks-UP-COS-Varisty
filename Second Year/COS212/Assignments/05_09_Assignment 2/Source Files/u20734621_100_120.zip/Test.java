public class Test
{
	public static void main(String[] args)
	{
		/*
		// Write code to test your implementation here.
		MinMaxDHeap<Integer> mmh = new MinMaxDHeap<Integer>(2);

		Node[] values = new Node[10];
		for (int i = 1; i <= 10; i++) {
			values[i - 1] = new Node<Integer>(i, i);
		}
		mmh.construct(values);
		System.out.println(mmh);
		//System.out.println(mmh.isLeaf(0));

/*
		mmh.insert(24, 24);
		System.out.println(mmh);
		mmh.insert(38, 38);
		System.out.println(mmh);
		mmh.insert(36, 36);
		System.out.println(mmh);
		mmh.insert(21, 21);
		System.out.println(mmh);
		mmh.insert(7,7);
		System.out.println(mmh);
		mmh.insert(4,4);
		System.out.println(mmh);
		mmh.insert(8,8);
		System.out.println(mmh);
		mmh.insert(9,9);
		System.out.println(mmh);
		System.out.println(mmh.getLastNonLeaf());

		/*
		System.out.println(mmh);
		System.out.println("DELETED = " + mmh.deleteMax());
		System.out.println(mmh);
		System.out.println("DELETED = " + mmh.deleteMax());
		System.out.println(mmh);
		System.out.println("DELETED = " + mmh.deleteMax());
		System.out.println(mmh);
		System.out.println("DELETED = " + mmh.deleteMax());
		System.out.println(mmh);
		System.out.println("DELETED = " + mmh.deleteMax());
		System.out.println(mmh);
		System.out.println("DELETED = " + mmh.deleteMax());
		System.out.println(mmh);
		System.out.println("DELETED = " + mmh.deleteMax());
		System.out.println(mmh);
		System.out.println("DELETED = " + mmh.deleteMax());
		System.out.println("Empty List Here -> " + mmh);
		//System.out.println("DELETING:");
		/*
		System.out.println("Removed = " + mmh.deleteMin());
		System.out.println(mmh);
		System.out.println("Removed = " + mmh.deleteMin());
		System.out.println(mmh);
		System.out.println("Removed = " + mmh.deleteMin());
		System.out.println(mmh);
		System.out.println("Removed = " + mmh.deleteMin());
		System.out.println(mmh);
		System.out.println("Removed = " + mmh.deleteMin());
		System.out.println(mmh);
		System.out.println("Removed = " + mmh.deleteMin());
		System.out.println(mmh);
		System.out.println("Removed = " + mmh.deleteMin());
		System.out.println(mmh);
		System.out.print("Removed = " + mmh.deleteMin());
		System.out.println(mmh);
		System.out.print("Nothing here-> " + mmh);
		*/





/*
		System.out.println(mmh);
		mmh.clear();
		System.out.println("Cleared");
		System.out.println(mmh.peekMin());
*/

	}
}
