/**
 * Name:
 * Student Number:
 */

public class Coordinates {

    public Integer row;
    public Integer col;

    public Coordinates(Integer row, Integer col) {
        // TODO: Your code here...
    }

}
