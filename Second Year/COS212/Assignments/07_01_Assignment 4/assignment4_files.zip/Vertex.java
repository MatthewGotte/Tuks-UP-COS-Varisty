/**
 * Name:
 * Student Number:
 */

public class Vertex {
   
    public Coordinates coords;
    
    public Vertex() {
        // TODO: Your code here...
    }
}
