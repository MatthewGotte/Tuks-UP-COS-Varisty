/**
 * Name: Matthew Gotte
 * Student Number: u20734621
 */

public class Main {

    public static void main(String[] args) {
        // TODO: Write tests here...
//        DungeonGraph test = new DungeonGraph();
//        test.createGraph("test.txt");
//        System.out.println(test.toString());
//        System.out.println(test.getKey().coords.row + ", " + test.getKey().coords.col);
    }
}
