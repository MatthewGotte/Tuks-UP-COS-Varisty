/**
 * Name: Matthew Gotte
 * Student Number: u20734621
 */

public class Coordinates {

    public Integer row;
    public Integer col;

    public Coordinates(Integer row, Integer col) {
        // TODO: Your code here...
        this.row = row;
        this.col = col;
    }

}
