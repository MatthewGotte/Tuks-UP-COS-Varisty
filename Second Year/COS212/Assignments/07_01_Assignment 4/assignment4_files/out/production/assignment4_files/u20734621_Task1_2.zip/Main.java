/**
 * Name: Lisa Rotter
 * Student Number: u19072067
 */

public class Main {
    public static void testAdj(DungeonGraph graph, Vertex v)
    {
        Vertex [] list = graph.getAdjacentVertices(v);

        //System.out.println("\ttesting adjacenct vertices of: "+v.getName());

        System.out.print("\t");
        if(list.length==0)
        {
            System.out.println("null");
            return;
        }
        System.out.print(list[0].CoordsToString());
        for(int i=1  ;  i< list.length  ;  i ++)
            System.out.print(","+list[i].CoordsToString());
        System.out.println();
    }

    public static void Test()
    {
        System.out.println("\n1.  Random Test");
        DungeonGraph graph1 = new DungeonGraph();
        graph1.createGraph("file.txt");

        //System.out.println("\t"+graph1.toString());
        graph1.getVertex(3,2);

        Vertex E = graph1.getDoor();
        Vertex K = graph1.getKey();
        Vertex T = graph1.getTreasure();
        Vertex random = new Vertex(6,0);

        System.out.println("\tEntrance is at "+E.CoordsToString());
        System.out.println("\tKey is at "+K.CoordsToString());
        System.out.println("\tTreasure is at "+T.CoordsToString());

        testAdj(graph1,E);
        testAdj(graph1,T);
        testAdj(graph1,K);
        testAdj(graph1,random);

    }



    /**     TESTING TASK 1   */

    public static void Task1_Test1()
    {
        System.out.println("\n1.  test small dungeon");
        DungeonGraph graph1 = new DungeonGraph();
        graph1.createGraph("file1.txt");

        System.out.println("\t"+graph1.toString());

        Vertex E = graph1.getDoor();
        Vertex K = graph1.getKey();
        Vertex T = graph1.getTreasure();

        System.out.println("\tEntrance is at "+E.CoordsToString());
        System.out.println("\tKey is at "+K.CoordsToString());
        System.out.println("\tTreasure is at "+T.CoordsToString());

        testAdj(graph1,E);
        testAdj(graph1,T);
        testAdj(graph1,K);

        /*
        1.  test small dungeon
        (1,0),(1,1),(1,2),(1,3),(2,3)

        Entrance is at (1,0)
        Key is at (1,2)
        Treasure is at (2,3)
        (1,1),(1,3),
        */
    }

    public static void Task1_Test2()
    {
        System.out.println("\n2.  small dungeon no walls inside");
        DungeonGraph graph1 = new DungeonGraph();
        graph1.createGraph("file2.txt");

        System.out.println("\t"+graph1.toString());

        Vertex E = graph1.getDoor();
        Vertex K = graph1.getKey();
        Vertex T = graph1.getTreasure();

        System.out.println("\tEntrance is at "+E.CoordsToString());
        System.out.println("\tKey is at "+K.CoordsToString());
        System.out.println("\tTreasure is at "+T.CoordsToString());

        testAdj(graph1,E);
        testAdj(graph1,T);
        testAdj(graph1,K);

        /*
        2.  small dungeon no walls inside
            (1,0),(1,1),(1,2),(1,3),(2,3),(2,2),(2,1)

            Entrance is at (1,0)
            Key is at (1,2)
            Treasure is at (2,3)
            (1,1),(1,3),(2,2),
        */
    }

    public static void Task1_Test3()
    {
        System.out.println("\n3.  small dungeon bottom entrance");
        DungeonGraph graph1 = new DungeonGraph();
        graph1.createGraph("file3.txt");

        System.out.println("\t"+graph1.toString());

        Vertex E = graph1.getDoor();
        Vertex K = graph1.getKey();
        Vertex T = graph1.getTreasure();

        System.out.println("\tEntrance is at "+E.CoordsToString());
        System.out.println("\tKey is at "+K.CoordsToString());
        System.out.println("\tTreasure is at "+T.CoordsToString());

        System.out.print("\t");
        Vertex [] list1 = graph1.getAdjacentVertices(K);
        for(int i=0  ;  i< list1.length  ;  i ++)
            System.out.print(list1[i].CoordsToString()+",");
        System.out.println();

        /*
        3.  small dungeon bottom entrance
        (4,2),(3,2),(2,2),(2,1),(1,1),(1,2),(1,3),(2,3)

        Entrance is at (4,2)
        Key is at (1,1)
        Treasure is at (2,1)
        (1,2),(2,1),
        */
    }

    public static void Task1_Test4()
    {
        System.out.println("\n4.  small dungeon, right entrance, T adjacent E");
        DungeonGraph graph1 = new DungeonGraph();
        graph1.createGraph("file4.txt");

        System.out.println("\t"+graph1.toString());

        Vertex E = graph1.getDoor();
        Vertex K = graph1.getKey();
        Vertex T = graph1.getTreasure();

        System.out.println("\tEntrance is at "+E.CoordsToString());
        System.out.println("\tKey is at "+K.CoordsToString());
        System.out.println("\tTreasure is at "+T.CoordsToString());

        System.out.print("\t");
        Vertex [] list1 = graph1.getAdjacentVertices(K);
        for(int i=0  ;  i< list1.length  ;  i ++)
            System.out.print(list1[i].CoordsToString()+",");
        System.out.println();

        /*
        4.  small dungeon, right entrance, T adjacent E
            (1,4),(1,3),(1,2),(2,2),(2,1)

            Entrance is at (1,4)
            Key is at (2,1)
            Treasure is at (1,3)
            (2,2),
	*/
    }

    public static void Task1_Test5()
    {
        System.out.println("\n5.  small dungeon, top entrance, K adjacent to E");
        DungeonGraph graph1 = new DungeonGraph();
        graph1.createGraph("file5.txt");

        System.out.println("\t"+graph1.toString());

        Vertex E = graph1.getDoor();
        Vertex K = graph1.getKey();
        Vertex T = graph1.getTreasure();

        System.out.println("\tEntrance is at "+E.CoordsToString());
        System.out.println("\tKey is at "+K.CoordsToString());
        System.out.println("\tTreasure is at "+T.CoordsToString());

        System.out.print("\t");
        Vertex [] list1 = graph1.getAdjacentVertices(K);
        for(int i=0  ;  i< list1.length  ;  i ++)
            System.out.print(list1[i].CoordsToString()+",");
        System.out.println();

        /*
        5.  small dungeon, top entrance, K adjacent to E
            (0,1),(1,1),(2,1),(2,2),(2,3),(1,3)

            Entrance is at (0,1)
            Key is at (1,1)
            Treasure is at (2,3)
            (0,1),(2,1),
        */
    }

    public static void Task1_Test6()
    {
        System.out.println("\n6.  Large Dungeon");
        DungeonGraph graph1 = new DungeonGraph();
        graph1.createGraph("file6.txt");

        System.out.println("\t"+graph1.toString());

        Vertex E = graph1.getDoor();
        Vertex K = graph1.getKey();
        Vertex T = graph1.getTreasure();

        System.out.println("\tEntrance is at "+E.CoordsToString());
        System.out.println("\tKey is at "+K.CoordsToString());
        System.out.println("\tTreasure is at "+T.CoordsToString());

        System.out.print("\t");
        Vertex [] list1 = graph1.getAdjacentVertices(K);
        for(int i=0  ;  i< list1.length  ;  i ++)
            System.out.print(list1[i].CoordsToString()+",");
        System.out.println();

        /*
        6.  Large Dungeon
            (1,0),(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(2,10),(2,11),(2,12),(2,13),(3,13),(4,13),(5,13),(5,12),(5,11),(5,10),(4,10),(4,9),(4,8),(4,7),(4,6),(3,6),(2,6)

            Entrance is at (1,0)
            Key is at (4,10)
            Treasure is at (4,13)
            (4,9),(5,10),
        */
    }

    public static void Task1_Test7()
    {
        System.out.println("\n7.  tiny dungeon, T adjacent to E and K");
        DungeonGraph graph1 = new DungeonGraph();
        graph1.createGraph("file7.txt");

        System.out.println("\t"+graph1.toString());

        Vertex E = graph1.getDoor();
        Vertex K = graph1.getKey();
        Vertex T = graph1.getTreasure();

        System.out.println("\tEntrance is at "+E.CoordsToString());
        System.out.println("\tKey is at "+K.CoordsToString());
        System.out.println("\tTreasure is at "+T.CoordsToString());

        System.out.print("\t");
        Vertex [] list1 = graph1.getAdjacentVertices(K);
        for(int i=0  ;  i< list1.length  ;  i ++)
            System.out.print(list1[i].CoordsToString()+",");
        System.out.println();

        /*
        7.  tiny dungeon, T adjacent to E and K
            (0,0),(0,1),(0,2)

            Entrance is at (0,0)
            Key is at (0,2)
            Treasure is at (0,1)
            (0,1),
	*/
    }

    /**     TESTING TASK 2   */
    public static void Task2_Test1()
    {
        System.out.println("Testing Task 2_1");
        DungeonGraph graph = new DungeonGraph();
        graph.createGraph("file1.txt");

        graph.getShortestPath();
        System.out.println(graph.getShortestPathString());
        /*
        Testing Task 2_1
right, right, right, right, down, down, left, left, left, up, up, left

        * */
    }

    public static void Task2_Test2()
    {
        System.out.println("Testing Task 2_2");
        DungeonGraph graph = new DungeonGraph();
        graph.createGraph("file2.txt");

        graph.getShortestPath();
        System.out.println(graph.getShortestPathString());
        /*
        * Testing Task 2_2
right, right, right, right, right, right, down, down, down, right, right, right, right, down, right, right, right, up, up, up, left, left, left, up, left, left, left, left, left, left, left, left, left, left
*/
    }

    public static void Task2_Test3()
    {
        System.out.println("Testing Task 2_3");
        DungeonGraph graph = new DungeonGraph();
        graph.createGraph("file3.txt");

        graph.getShortestPath();
        System.out.println(graph.getShortestPathString());

        /*
        * Testing Task 2_3
right, down, up, left
*/
    }



    /**     TESTING TASK 3   */



    public static void main(String[] args)
    {
        //Test();

//        System.out.println("TESTING TASK 1");
//        Task1_Test1();
//        Task1_Test2();
//        Task1_Test3();
//        Task1_Test4();
//        Task1_Test5();
//        Task1_Test6();
//        Task1_Test7();

        //System.out.println("TESTING TASK 2");
        // Task2_Test1();
        //Task2_Test2();
        //Task2_Test3();
    }
}


/*
"C:\Program Files\Java\jdk1.8.0_281\bin\java.exe" -javaagent:C:\Users\lisar\AppData\Local\JetBrains\Toolbox\apps\IDEA-U\ch-0\203.7717.56\lib\idea_rt.jar=51865:C:\Users\lisar\AppData\Local\JetBrains\Toolbox\apps\IDEA-U\ch-0\203.7717.56\bin -Dfile.encoding=UTF-8 -classpath "C:\Program Files\Java\jdk1.8.0_281\jre\lib\charsets.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\deploy.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\access-bridge-64.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\cldrdata.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\dnsns.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\jaccess.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\jfxrt.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\localedata.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\nashorn.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\sunec.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\sunjce_provider.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\sunmscapi.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\sunpkcs11.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\ext\zipfs.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\javaws.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\jce.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\jfr.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\jfxswt.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\jsse.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\management-agent.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\plugin.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\resources.jar;C:\Program Files\Java\jdk1.8.0_281\jre\lib\rt.jar;C:\Users\lisar\OneDrive\01_Education\University of Pretoria\Year 2\Semester 1\COS212\Assignments\Assignment 4\assignment4_files\out\production\assignment4_files" Main

1.  Random Test
	Entrance is at (0,3)
	Key is at (3,3)
	Treasure is at (5,5)
	testing adjacenct vertices of: E
	(1,3)
	testing adjacenct vertices of: T
	(5,4),(4,5),(5,6)
	testing adjacenct vertices of: K
	(3,2),(3,4),(4,3)
	testing adjacenct vertices of: random
	null
TESTING TASK 1

1.  test small dungeon
	(1,0),(1,1),(1,2),(1,3),(2,3)
	Entrance is at (1,0)
	Key is at (1,2)
	Treasure is at (2,3)
	testing adjacenct vertices of: E
	(1,1)
	testing adjacenct vertices of: T
	(1,3)
	testing adjacenct vertices of: K
	(1,1),(1,3)

2.  small dungeon no walls inside
	(1,0),(1,1),(1,2),(1,3),(2,3),(2,2),(2,1)
	Entrance is at (1,0)
	Key is at (1,2)
	Treasure is at (2,3)
	testing adjacenct vertices of: E
	(1,1)
	testing adjacenct vertices of: T
	(2,2),(1,3)
	testing adjacenct vertices of: K
	(1,1),(1,3),(2,2)

3.  small dungeon bottom entrance
	(4,2),(3,2),(2,2),(2,1),(1,1),(1,2),(1,3),(2,3)
	Entrance is at (4,2)
	Key is at (1,1)
	Treasure is at (2,1)
	(1,2),(2,1),

4.  small dungeon, right entrance, T adjacent E
	(1,4),(1,3),(1,2),(2,2),(2,1)
	Entrance is at (1,4)
	Key is at (2,1)
	Treasure is at (1,3)
	(2,2),

5.  small dungeon, top entrance, K adjacent to E
	(0,1),(1,1),(2,1),(2,2),(2,3),(1,3)
	Entrance is at (0,1)
	Key is at (1,1)
	Treasure is at (2,3)
	(0,1),(2,1),

6.  Large Dungeon
	(1,0),(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(2,10),(2,11),(2,12),(2,13),(3,13),(4,13),(5,13),(5,12),(5,11),(5,10),(4,10),(4,9),(4,8),(4,7),(4,6),(3,6),(2,6)
	Entrance is at (1,0)
	Key is at (4,10)
	Treasure is at (4,13)
	(4,9),(5,10),

7.  tiny dungeon, T adjacent to E and K
	(0,0),(0,1),(0,2)
	Entrance is at (0,0)
	Key is at (0,2)
	Treasure is at (0,1)
	(0,1),

Process finished with exit code 0


* */