/**
 * Name: Matthew Gotte
 * Student Number: u20734621
 */

public class Vertex {
   
    public Coordinates coords;
    
    public Vertex() {
        // TODO: Your code here...
    }
}
