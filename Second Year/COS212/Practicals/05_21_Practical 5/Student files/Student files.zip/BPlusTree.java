/*
	You may not change the signatures of any of the given methods.  You may 
	however add any additional methods and/or field(s) which you may require to aid 
	you in the completion of this practical.
 */

public class BPlusTree {
	int order;
	int minKeys;
	int maxKeys;
	BPlusNode root; // do not modify

	public BPlusTree(int m) {
		/*
		The constructor.  Creates a BPlusTree object of order m,
		where m is passed as a parameter to the constructor. 
		You may assume that m >= 3.
		*/
		order = m;
		minKeys = (int) Math.ceil(m / 2.0) - 1;
		maxKeys = order - 1;
		root = new BPlusNode(m, true); /* root starts as leaf node and root's parent is null */
	}

	/* insert an element into the BPlusTree, you may assume duplicates will not be inserted. */
	public void insertElement(int element) {
		// your code goes here

		//get insert node:
		BPlusNode temp = insertNode(element);

		if (!temp.isFull()) {
			temp = shiftInsert(temp, element);
			return;
		}

		//overflow has occurred:

		//overflow on the root:
		if (temp == root) {
			//System.out.println("overflow on the root");
			BPlusNode ins = new BPlusNode(order + 1, false);
			//copy to ins:
			for (int i = 0; i < temp.keyTally; i++) {
				ins.keys[i] = temp.keys[i];
			}
			ins.keyTally = temp.keyTally;
			ins = shiftInsert(ins, element);
			rootOverflow(ins);
			return;
		}

		//overflow on temp:
		//check if parent is not full:
		if (!temp.parent.isFull()) {
			System.out.println("Overflow on temp with space in parent...");

			//leaf has overflowed but parent has space for index:
			//calculate split:
			int splitter = order / 2;//+1?

			BPlusNode list = new BPlusNode(order + 1, false);
			//copy to ins:
			for (int i = 0; i < temp.keyTally; i++) {
				list.keys[i] = temp.keys[i];
				list.branches[i] = temp.branches[i];////////////////////////
			}
			list.keyTally = temp.keyTally;
			list = shiftInsert(list, element);

			//make new right sibling;
			BPlusNode rightSib = new BPlusNode(order, true);
			for (int i = splitter, p = 0; i < list.keyTally; i++, p++) {
				rightSib.keys[p] = list.keys[i];
				list.branches[p] = temp.branches[i];////////////////////////
				rightSib.keyTally++;
			}
			//clear copied values from old temp:
			for (int i = splitter; i < temp.keyTally; i++) {
				temp.keys[i] = 0;
				temp.branches[i] = null;/////////////////////
				temp.keyTally-=2;//IDK about this? not maybe --?
			}

			//link children and parent
			rightSib.next = temp.next;
			temp.next = rightSib;
			rightSib.parent = temp.parent;

			temp.parent = shiftInsert(temp.parent, rightSib.keys[0]);
			temp.parent.branches[temp.parent.keyTally] = rightSib;

			return;
		}

		//leaf has overflowed but parent does not have space :-/
		System.out.println("Overflow on temp no space in parent...");

		//System.out.println("overflow on the root");
		BPlusNode ins = new BPlusNode(order + 1, false);
		//copy to ins:
		for (int i = 0; i < temp.keyTally; i++) {
			ins.keys[i] = temp.keys[i];
			ins.branches[i] = temp.branches[i];
		}
		ins.keyTally = temp.keyTally;
		ins = shiftInsert(ins, element);
		parentOverflow(temp, element, null);

	}

	public void parentOverflow(BPlusNode temp, int element, BPlusNode rightSib_ptr) {
		//System.out.print("INDEX IS OVERFLOWING!!!!!!!!!!!!!");
		//is overflowing parent the root?
		if (temp.parent == root) {
			int splitter = order / 2;//+1?

			BPlusNode list = new BPlusNode(order + 1, false);
			//copy to ins:
			for (int i = 0; i < temp.keyTally; i++) {
				list.keys[i] = temp.keys[i];
			}
			list.keyTally = temp.keyTally;
			list = shiftInsert(list, element);

			//make new right sibling;
			BPlusNode rightSib = new BPlusNode(order, true);
			for (int i = splitter, p = 0; i < list.keyTally; i++, p++) {
				rightSib.keys[p] = list.keys[i];
				rightSib.keyTally++;
			}
			//clear copied values from old temp:
			for (int i = splitter; i < temp.keyTally; i++) {
				temp.keys[i] = 0;
				temp.keyTally-=2;//IDK about this? not maybe --?
			}
			//make new root:
			BPlusNode newroot = new BPlusNode(order, false);
			newroot.branches[0] = temp;
			newroot.branches[1] = rightSib;
			for (int i = 0; i < temp.keyTally; i++) {
				temp.branches[i] = root.branches[i];
			}
			for (int i = 0; i < rightSib.keyTally; i++) {
				rightSib.branches[i] = root.branches[i];
			}
			newroot.keys[0] = rightSib.keys[0];
			newroot.keyTally++;
			root = newroot;
			return;
		}
			//getting split nodes:

			int splitter = order / 2;//+1?

			BPlusNode list = new BPlusNode(order + 1, false);
			//copy to ins:
			for (int i = 0; i < temp.keyTally; i++) {
				list.keys[i] = temp.keys[i];
			}
			list.keyTally = temp.keyTally;
			list = shiftInsert(list, element);

			//make new right sibling;
			BPlusNode rightSib = new BPlusNode(order, true);
			for (int i = splitter, p = 0; i < list.keyTally; i++, p++) {
				rightSib.keys[p] = list.keys[i];
				rightSib.keyTally++;
			}
			//clear copied values from old temp:
			for (int i = splitter; i < temp.keyTally; i++) {
				temp.keys[i] = 0;
				temp.keyTally-=2;//IDK about this? not maybe --?
			}
			//temp = left split, rightSib = right split.
			if (temp.leaf) {
				//link siblings
				rightSib.next = temp.next;
				temp.next = rightSib;
				BPlusNode rightChild = rightSib;
			}
			else {
				rightSib.branches[0] = rightSib_ptr;
			}

			BPlusNode push = new BPlusNode(order + 1, false);
			//copy to ins:
			for (int i = 0; i < temp.keyTally; i++) {
				push.keys[i] = temp.keys[i];
			}
			push.keyTally = temp.keyTally;
			push = shiftInsert(push, element);
			parentOverflow(temp.parent, element, rightSib);


		//overflowing parent is not the root:

	}

	public void rootOverflow(BPlusNode newStruct) {
		//System.out.println("overflow data = " + newStruct);

		//make new root:
		BPlusNode newRoot = new BPlusNode(order, false);

		//calculate split:
		int splitter = order / 2;
		//System.out.println("SPLITTER = " + splitter);
		BPlusNode left = new BPlusNode(order, true);
		for (int i = 0; i < splitter; i++) {
			left.keys[i] = newStruct.keys[i];
			left.keyTally++;
		}
		BPlusNode right = new BPlusNode(order, true);
		for (int i = splitter, p = 0; i < order; i++, p++) {
			right.keys[p] = newStruct.keys[i];
			right.keyTally++;
		}

		//set pointers:
		left.next = right;
		left.parent = newRoot;
		right.parent = newRoot;
		newRoot.branches[0] = left;
		newRoot.branches[1] = right;

		//get copy data:
		newRoot.keys[0] = right.keys[0];
		newRoot.keyTally++;

		this.root = newRoot;
	}

	public BPlusNode insertNode(int element) {
		//Check if root is leaf:
		if (root.leaf) {
			return root;
		}
		//Set temp = root, iterate through each for pos, then go to branch[i]
		BPlusNode temp = root;
		while (!temp.leaf) {
			for (int i = 0; i < temp.keyTally; i++) {
				if (element < temp.keys[i]) {
					temp = temp.branches[i];
					break;
				}
			}
			temp = temp.branches[temp.keyTally];
		}
		//node to potentially insert into:
		return temp;
	}

	public BPlusNode shiftInsert(BPlusNode node, int element) {
		//double check the node:
		if (node.isFull()) {
			System.out.println("ERROR IN SHIFT UP!");
			return null;
		}
		if (node.keyTally == 0) {
			node.keys[0] = element;
			node.keyTally++;
			return node;
		}
		if (node.keyTally == 1) {
			if (node.keys[0] > element) {
				node.keys[1] = node.keys[0];
				node.keys[0] = element;
				node.keyTally++;
				return node;
			}
		}
		//get index to insert to:
		int pos = node.keyTally;//assume insert at back
		for (int i = 0 ; i < node.keyTally ; i++) {
			if (node.keys[i] > element) {
				pos = i;
				break;
			}
		}
		//perform shift:
		if (pos == node.keyTally) {
			//insert at back:
			node.keys[pos] = element;
		}
		else {
			//nested insert:
			for (int i = node.keyTally; i >= 0; i--) {
				if (i == pos) break;
				node.keys[i] = node.keys[i - 1];
			}
			node.keys[pos] = element;
		}
		node.keyTally++;
		return node;
	}

	/*
	    This method should return the left-most leaf node in the tree.
		If the tree is empty, return null.
	 */
	public BPlusNode getFirstLeaf() {
		// your code goes here
		if (root.keyTally == 0) return null;
		return getleaf(root);
	}

	public BPlusNode getleaf(BPlusNode temp) {
		if (temp.leaf) {
			return temp;
		}
		return getleaf(temp.branches[0]);
	}

}
